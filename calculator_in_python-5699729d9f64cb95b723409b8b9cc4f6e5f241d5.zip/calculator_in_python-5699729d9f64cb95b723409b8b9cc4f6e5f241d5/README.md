# calculator_in_python

1.Run the given file after downloding in IDE (python).

2.We have imported Tkinter module

